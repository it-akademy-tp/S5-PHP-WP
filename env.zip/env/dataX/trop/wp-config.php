<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'trop' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '0000' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'F;[cs2O{5:u8zKBZdsJ=)5qeWB+u/0*@!(5c|(5hYpY<VqaA`]cT2U`nqhFihTMU' );
define( 'SECURE_AUTH_KEY',  'Pa$:@-~&T2|fJAWlMR^V.M#nJ>>o}:c)b#;3sQM&DJkX(<QoX?cfdd:@4k3KG6Ha' );
define( 'LOGGED_IN_KEY',    '/hs-t=m@f&vMDH3v(JreS40hO9dF |BBRum_>wc>r?CozxlZUGh)Jk:=`IMF]lc`' );
define( 'NONCE_KEY',        'P7GK-04rH@p+n)0S%k1-phkm.rvbu)deM{L~jrcV K<VW.[Kh!<fy*KPWoBf[PmP' );
define( 'AUTH_SALT',        'hauXyFIv_1w*yR!}<T|`|PO>:prVuh^w8#Oy&_INg]S~D<zkUp^lS3$swR][laID' );
define( 'SECURE_AUTH_SALT', 'b>pK#Lb&KJkfra*Tft)-.]E?sT/)&glq;GxJ. 7K_qy/:Y}?EN|2mFHpUDz8)0<P' );
define( 'LOGGED_IN_SALT',   'yBe9FKFXMn{_RK?K<v;&BrX6!YUxQp@Lp#vU_kIfJw?NK[B{(jBK#?adawz]02D,' );
define( 'NONCE_SALT',       'aXZ8NI{@DZHXC#!1?:/,E?tFUl0LrJQH7u{7C.8{VI`[BbjfMq>v@^M]7yJ.i>_|' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
